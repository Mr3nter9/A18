import os
try:
    from telethon.tl.functions.messages import GetHistoryRequest
    from telethon.sync import TelegramClient
    from telethon.tl.functions.channels import JoinChannelRequest
    from telethon.tl.functions.messages import ImportChatInviteRequest
    import requests
    from time import sleep
except Exception:
    os.system('pip install requests')
    os.system('pip install bs4')
    os.system('pip install BeautifulSoup')
    os.system('pip install telethon')
from telethon.tl.functions.messages import GetHistoryRequest
from telethon import TelegramClient , sync
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import ImportChatInviteRequest
import requests
from time import sleep

def dex3():
    api_id = 12345
    api_hash = '0123456789abcdef0123456789abcdef'

    def sol(cc):
        client = TelegramClient(cc, api_id, api_hash)
        client.connect()
        client(JoinChannelRequest('@crsv3'))
        m=client.get_messages('@crsv3',limit=3)
        xx = m[3].message
        if xx == 'dex':
            m[3].click(0)
        else:
            print('not')


    g = 1
    for ffguf in range(91):
        sleep(0.5)
        sol('dex' + str(g))
        if 91==g:
            print("  Completed")
        g = g + 1

dex3()