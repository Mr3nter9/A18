from telethon.sync import *
from time import sleep
import requests

userbot='@zmmbot'
Dex = '6140911166'
Des = '6243358528:AAFaAucqXoIHltgcKhKwlpkv6ZqcfVuhhi8'
V=58
def sd(B):
    requests.post(f'https://api.telegram.org/bot{Des}/sendMessage?chat_id={Dex}&text={B}')
def dele():
    def dle(cc):
        try:
            client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
            client.start()
            sleep(1)
            client.send_message(userbot, '/start')
            sleep(2)
            mess1 = client.get_messages(userbot, limit=1)
            mess1[0].click(1)
            sleep(1)
            mmess1 = client.get_messages(userbot, limit=1)
            mmess1[0].click(0)
            sleep(1)
            mess1 = client.get_messages(userbot, limit=1)
            mess1[0].click(2)
            sleep(1)
            client.send_message(userbot,'@dexsuper')
            client.disconnect()
            sd(cc)
        except Exception:
            pass
    g = 1
    for ffguf in range(1000):
        F = ("dex" + str(g))
        dle(F)

        if int(g) == int(V):
            sd('cliened')
            break
        else:
            g = g + 1
dele()