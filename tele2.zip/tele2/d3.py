from telethon.sync import TelegramClient
from telethon.tl.functions.channels import JoinChannelRequest
import re
import requests
from time import sleep

Dex = '5229914714'
Des = '5938772476:AAHaSgf6WdTHQd1RqUifucJaaf11CQ0tkAg'
def sd(B):
    requests.post(f'https://api.telegram.org/bot{Des}/sendMessage?chat_id={Dex}&text={B}')

userbot='@DamKombot'
def dex2():
    V=58
    def sing(cc):
        client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
        client.start()
        sleep(0.5)
        client.send_message(userbot, '/start')
        sleep(3)
        try:
            for x in range(22):
                l1 = client.get_messages(userbot, limit=1)
                l2=l1[0].message
                if l2 == "/start":
                    client.send_message(userbot, '/start')
                    sleep(1)
                    continue
                if l2 == "البوت تحت الصيانة حالياً 🛠️":
                    sleep(7000)
                    client.send_message(userbot, '/start')
                    sleep(1)
                    continue
                rege = r'يجب'
                matches = re.search(rege, l2)
                if matches != None :
                    regex = r'[-+qwertyuiopasdfghjklzxcvbnmPOIUYTREWQASDFGHJKLZXCVBNM1234567890]\w+'
                    sht = re.findall(regex, l2)
                    print(sht)
                    if sht[1] == 'start':
                        try:
                            cx = "https://t.me" + sht[0]
                            print(cx)
                            client(JoinChannelRequest(cx))
                        except Exception:
                            cx = "https://t.me/" + sht[0]
                            print(cx)
                            client(JoinChannelRequest(cx))
                    elif sht[3] == 'start':
                        try:
                            c = "https://t.me" + sht[2]
                            print(c)
                            client(JoinChannelRequest(c))
                        except Exception:
                            c = "https://t.me/" + sht[2]
                            print(c)
                            client(JoinChannelRequest(c))
                    elif sht[4] == 'start':

                        try:
                            t = "https://t.me" + sht[2] + sht[3]
                            client(JoinChannelRequest(t))
                        except Exception:
                            try:
                                t = "https://t.me/" + sht[2] + sht[3]
                                client(JoinChannelRequest(t))
                            except Exception:
                                t = "https://t.me/" + sht[2] +'/'+ sht[3]
                                client(JoinChannelRequest(t))
                    else:
                        try:
                            r = "https://t.me" + sht[2] + sht[3] + sht[4]
                            client(JoinChannelRequest(r))
                        except Exception:
                            try:
                                r = "https://t.me/" + sht[2] + sht[3] + sht[4]
                                client(JoinChannelRequest(r))
                            except Exception :
                                r = "https://t.me/" + sht[2] +'/'+ sht[3] + sht[4]
                                client(JoinChannelRequest(r))
                                #########+___+########
                    client.send_message(userbot, '/start')
                    sleep(1)
                else:
                    sleep(1)
                    mscsag33 = client.get_messages(userbot, limit=1)
                    mscsag33[0].click(1)
                    sleep(3)
                    mscsag34 = client.get_messages(userbot, limit=1)
                    mscsag34[0].click(0)
                    sleep(3)
                    for ee in range(25):
                        try:
                            mscsag35 = client.get_messages(userbot, limit=1)
                            l2 = mscsag35[0].message
                            if 'لا يوجد قنوات حالياً 🤍' in l2:
                                break
                            r = r'[^اشترك فالقناة @]\w+'
                            sht = re.findall(r, l2)
                            client(JoinChannelRequest(sht[0]))
                            mscsag36 = client.get_messages(userbot, limit=1)
                            mscsag36[0].click(0)
                            sleep(3)
                        except:
                            mscsag36 = client.get_messages(userbot, limit=1)
                            mscsag36[0].click(0)
                    sleep(3)
                    mscsag38 = client.get_messages(userbot, limit=1)
                    mscsag38[0].click(0)
                    sleep(3)
                    mssag11 = client.get_messages(userbot, limit=1)
                    x = mssag11[0].click(2).message
                    sd(cc + x)
                    mscsag40 = client.get_messages(userbot, limit=1)
                    m40 = mscsag40[0].message
                    if '🗃️ الحساب' in m40:
                        sleep(3)
                        mscsag37 = client.get_messages(userbot, limit=1)
                        mscsag37[0].click(2)
                        sleep(3)
                        l14 = client.get_messages(userbot, limit=1)
                        l24 = l14[0].message
                        regex1 = r'[1234567890]\w+'
                        she = re.findall(regex1, l24)
                        sleep(3)
                        mscsag5 = client.get_messages(userbot, limit=1)
                        mscsag5[0].click(4)
                        sleep(1)
                        client.send_message(userbot, Dex)
                        sleep(2)
                        client.send_message(userbot, she[0])
                        client.disconnect()
                        break
                    else:
                        break
        except:
            print('gg')
            try:
                client.disconnect()
            except:
                pass

    for ffguf in range(10000000):
        g = 1
        for ffguf in range(1000):
            F = ("dex" + str(g))
            sing(F)
            if int(g) == int(V):
                print('sleeping')
                sd('FFFFFF====')
                sleep(88000)
                break
            else:
                g = g + 1


dex2()