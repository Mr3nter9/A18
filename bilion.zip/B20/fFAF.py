from telethon.sync import TelegramClient
import requests
V=40
Dex = '5229914714'
Des = '5938772476:AAHaSgf6WdTHQd1RqUifucJaaf11CQ0tkAg'
def sd(B):
    requests.post(f'https://api.telegram.org/bot{Des}/sendMessage?chat_id={Dex}&text={B}')

def dle(cc):
    client=TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
    client.start()
    print(cc)
    dialogs = client.get_dialogs()

    for dialog in dialogs:
        entity = dialog.entity

        try:
            xu = entity.username
            xn = entity.title
        except:
            pass

        try:
            if xu == 'xnsex21bot':
                pass
            elif xu == 'DamKombot':
                pass
            elif xu == 'zmmbot':
                pass
            elif xu == 'Dexsuper':
                pass
            elif xu == 'KTTTT':
                pass
            elif xu == 'lI7777Il':
                pass
            elif xu == 'd3boot_7':
                pass
            elif xu == 'DzDDDD':
                pass
            elif xu == 'botbillion':
                pass
            elif xu == 'zzzzzz1':
                pass
            elif xu == 'Fvvvv':
                pass
            elif dialog.is_user:
                pass
            elif xn == 'مجموعة التخزين' or xn == 'كروب بوت جمثون' or xn == 'صيد':
                pass
            else:
                client.delete_dialog(entity)
        except:
            print('erorr')
g = 1
for ffguf in range(1000):
    F = ("dex" + str(g))
    dle(F)
    if int(g) == int(V):
        sd('sleeping')
        break
    else:
        g = g + 1
#elif xn == 'مجموعة التخزين' or entity.title == 'كروب بوت جمثون':
#pass