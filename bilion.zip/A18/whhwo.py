from telethon import TelegramClient, events


# قم بإنشاء عميل TelegramClient
client = TelegramClient('ledA', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')

# دالة لإرسال "Hello" عندما يرسل شخص ما أمر "/start" إلى البوت
waiting_for_response = False

# دالة للتحقق من الرسائل الواردة والرد عليها
@client.on(events.NewMessage)
async def handle_messages(event):
    if event.raw_text.lower() == '.':
        await event.respond('api_hash ?')

    if event.raw_text.lower()[:8] == 'api_hash':
        await event.respond('okk')




async def main():
    await client.start()
    await client.run_until_disconnected()

# قم بتشغيل الدالة الرئيسية
client.loop.run_until_complete(main())

#event.raw_text.lower()