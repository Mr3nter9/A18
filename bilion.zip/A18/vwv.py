import requests
import random
from time import sleep
import datetime
from telethon import TelegramClient
from telethon.tl.functions.messages import ImportChatInviteRequest

uss='qwertyuioplkjhgfdsazxcvbnm1234567890'
client = TelegramClient('ledA', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
client.start()
a = "https://t.me/+mwqfLXdPfKplMTFi"
url = a.split("/t.me/+")[1]
client(ImportChatInviteRequest('mwqfLXdPfKplMTFi'))


