import requests
import random
from time import sleep
import datetime
from telethon.sync import TelegramClient, events
from telethon import functions,types
uss='qwertyuioplkjhgfdsazxcvbnm1234567890'
rr='qwertyuioplkjhgfdsazxcvbnm'
client = TelegramClient('ledA', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
client.start()
time=datetime.datetime.now()
month=time.month
year=time.year
x=str(year)+'/'+str(month)
print(x)
Dex = '6140911166'
Des = '6243358528:AAFaAucqXoIHltgcKhKwlpkv6ZqcfVuhhi8'
g=1
for pp in range(3455):
    g=g+1
    u = str(''.join((random.choice(uss) for i in range(2))))
    e = str(''.join((random.choice(rr) for i in range(1))))
    user = e+u+'bot'
    print(user +' >> '+ str(g))
    req = requests.get(f"https://t.me/{user}").text

    if "you can view and join" in req:
        entity = client.get_entity(f'https://t.me/{user}')
        en=str(entity.date.year)+"/"+str(entity.date.month)
        print("  قناة" + user +en)
        if en == x:
            file1 = "udex.txt"
            o = open(file1, "r").read()
            if user + "\n" in o:
                pass
            else:
                with open(file1, 'a') as file:
                    file.write(user + '\n')
                    file.close()